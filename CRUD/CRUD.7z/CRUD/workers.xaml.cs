﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ZavyalovaCRUD.Pager
{
    /// <summary>
    /// Логика взаимодействия для workers.xaml
    /// </summary>
    public partial class workers : Page
    {
        public workers()
        {
            InitializeComponent();
           DGworkers.ItemsSource = vd.SoldatovaCRUDEntities.getcontext().Workers.ToList();
        }



        private void Delete(object sender, RoutedEventArgs e)
        {
            var workerForRemoving = DGworkers.SelectedItems.Cast<vd.Workers>().ToList();
            if (MessageBox.Show($"Вы хотите удалить{workerForRemoving.Count()}?","Ошибка", MessageBoxButton.YesNo,MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                try
                {
                    vd.SoldatovaCRUDEntities.getcontext().Workers.RemoveRange(workerForRemoving);
                    vd.SoldatovaCRUDEntities.getcontext().SaveChanges();
                    MessageBox.Show("молодец, ты всё удалил");
                }
                catch
                {
                    MessageBox.Show("нененене");
                }
            }
        }

        private void Add(object sender, RoutedEventArgs e)
        {
            classes.manager.MainFrame.Navigate(new Pager.EditWorkers(null));
        }

        private void Edit(object sender, RoutedEventArgs e)
        {
            classes.manager.MainFrame.Navigate(new Pager.EditWorkers((sender as Button).DataContext as vd.Workers));
        }
    }
}
